<?php
    
    $host = "localhost";
    $user = "root";
    $pass = "1234qwer";    
    $db = "prefixcinema";
    $link = new mysqli($host, $user, $pass, $db);
?>